(function () {
  if('serviceWorker' in navigator) {
    // navigator.serviceWorker.register('/smt/activitys/expermysz/sw.js');
  };
  // $("img.lazyload").lazyload()
})();

